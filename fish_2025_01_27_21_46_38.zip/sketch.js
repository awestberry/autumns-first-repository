function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  fill("hsl(200,100%,70%)");
  rect(0, 0, 400, 400);

  noStroke();
  fill("hsl(50, 100%, 80%)");
  rect(0, 300, 400, 400);
  
     fill("hsl(10, 100%, 65%)");
  triangle(200, 150, 300, 100, 300, 200,)


  fill("hsl(30, 100%, 65%)");
  ellipse(150, 150, 200, 130);


  fill("hsl(30, 100%, 100%)");
  ellipse(100, 150, 30, 30);

  fill("hsl(30, 100%, 0%)");
  ellipse(100, 150, 10, 10);
  
  fill("hsl(10, 100%, 65%)");
  triangle(150, 150, 180, 180, 150, 210,)
  
  
  arc(70, 190, 80, 13, 0, 360);
}
